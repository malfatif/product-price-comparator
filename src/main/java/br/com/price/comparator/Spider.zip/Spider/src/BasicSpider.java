import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;


public class BasicSpider {
	
	
	public BasicSpider() {

	}
	
	public void extrai(){
		String pagina = Util.openURLtoString("http://www.textfiles.com/etext/FICTION/");
		
		//System.out.println(pagina);
		
		
		String strs[] = pagina.split("\"");
		
		System.out.println("Strings "+strs.length);
		
		for(int i = 0; i < strs.length;i++){
			//System.out.println(""+strs[i]);
			
			if(strs[i].charAt(0)!='>'&&strs[i].contains(".txt")){
				
				System.out.println("Baixando "+strs[i]);
				Util.LoadFileUrl(new File("./download/"+strs[i]), "http://www.textfiles.com/etext/FICTION/"+strs[i]);
				
			}
		}
		
	}

}

